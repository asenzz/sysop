/*
 * About chsd.exe
 *
 * This will print on standard output security descriptor of a
 * file or directory on NTFS file system or modify it if specified.
 *
 * Zarko Asenov 2006
 *
 *
 */

#define _WIN32_WINNT 0x0500
#define _SEC_DESC_LN 0x0500

#include <windows.h>
#include <stdio.h>
#include <aclapi.h>

#include "sddl.h"
#include "util.h"

#define _DO_GET_TYPE	(0x1)

#define _OBJECT_TYPEL		('y')
#define _GET_SECURITY_INFOL 	('x')
#define _SET_SECURITY_INFOL 	('a')
#define _GET_DACLL 		('d')
#define _GET_SACLL 		('s')
#define _GET_OWNERL 		('o')
#define _GET_GROUPL 		('g')
#define _GET_PROTECTED_DACLL 	('p')
#define _GET_PROTECTED_SACLL 	('t')
#define _GET_UNPROTECTED_DACLL 	('u')
#define _GET_UNPROTECTED_SACLL 	('n')

#define _OBJECT_TYPE_REGISTRYH	('R')
#define _OBJECT_TYPE_FILEH	('F')
#define _OBJECT_TYPE_SERVICEH	('S')
#define _OBJECT_TYPE_PRINTERH	('P')
#define _OBJECT_TYPE_SHAREH	('H')
#define _OBJECT_TYPE_KERNELH	('K')
#define _OBJECT_TYPE_WINDOWH	('W')
#define _OBJECT_TYPE_DSOBJECTH	('D')
#define _OBJECT_TYPE_DSOBJALLH	('A')
#define _OBJECT_TYPE_PROVIDERH	('V')
#define _OBJECT_TYPE_WMIGUIDH	('G')
#define _OBJECT_TYPE_WOW64_REGH	('O')



BOOL APPLY_SECURITY_SETTINGS 	= 0;



VOID show_usage ()
{
	printf("CHSD\n");
	printf("Zarko Asenov 2006\n\n");
	printf("Modifies or displays security descriptor string of a specified\n");
	printf("object on Windows NT 4+ operating systems.\n\n\n");
	printf("Usage:\n");
	printf(" chsd.exe [-a|x][-y OBJECT_TYPE][-sdog][-pr|un]\"OBJECT_PATH_NAME\" [\"SECURITY_DESCRIPTOR_STRING\"]\n\n\n");
	printf("Options:\n\n");
	printf(" -a : Apply security descriptor string\n");
	printf(" -x : Extract security descriptor string (default)\n");
	printf(" -y : Object type\n");
	printf(" -s : Get SACL\n");
	printf(" -d : Get DACL\n");
	printf(" -o : Get owner\n");
	printf(" -g : Get group\n");
	printf(" -p : Indicates the DACL cannot inherit access control entries (ACEs). Windows NT:  This value is not supported.\n");
	printf(" -t : Indicates the SACL cannot inherit access control entries (ACEs). Windows NT:  This value is not supported.\n");
	printf(" -u : Indicates the DACL inherits ACEs from the parent object. Windows NT:  This value is not supported.\n");
	printf(" -n : Indicates the SACL inherits ACEs from the parent object. Windows NT:  This value is not supported.\n\n\n");
	printf("Object types:\n\n");
	printf(" REGISTRY	: R\n");
	printf(" FILE		: F (default)\n");
	printf(" SERVICE	: S\n");
	printf(" PRINTER	: P\n");
	printf(" SHARE		: H\n");
	printf(" KERNEL		: K\n");
	printf(" WINDOW		: W (non usable! *)\n");
	printf(" DSOBJECT	: D\n");
	printf(" DSOBJALL	: A\n");
	printf(" PROVIDER	: V\n");
	printf(" WMIGUID	: G\n");
	printf(" WOW64_REG	: O\n\n\n");
	printf("Examples: \n\n");
	printf("chsd -oxdspt \"c:\\WINDOWS\\SYSTEM32\"\t- will display protected security descriptor string for the SYSTEM32 folder containing owner, SACL and DACL.\n\n");
	printf("chsd -yads R \"MACHINE\\Software\\Microsoft\\Windows NT\" \"D:PAR(A;;KA;;;DU)\"\t- will give full access to the \"Domain Users\" group for the \"Windows NT\" registry key.\n\n\n");
	printf("* For object type reference see this page http://msdn.microsoft.com/library/default.asp?url=/library/en-us/secauthz/security/se_object_type.asp\n\n");
} /* show_usage() */


// Get error string of error number
char *get_error_string (DWORD err)
{
	char *szErr;
	if(FormatMessage(
			 FORMAT_MESSAGE_ALLOCATE_BUFFER | 
			 FORMAT_MESSAGE_FROM_SYSTEM,
			 NULL,
			 err,
			 0,
			 (LPTSTR) &szErr,
			 0,
			 NULL) != 0) 
		return szErr;
	return NULL;
} /* get_error_string() */


// Change process token privileges
int adjust_privileges (LPTSTR _privilege) 
{
	TOKEN_PRIVILEGES ns;
	HANDLE htoken;
	LUID LID;
	LUID_AND_ATTRIBUTES att;

	// Open process token
	if(!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES, &htoken)) {
  		printf("Can't open process token.\n");
  		return 1;
	}

	if(!LookupPrivilegeValue(NULL, _privilege, &LID)) {
  		printf("Can't look for required privileges.\n");
  		return 1;
	}

	// Enable for read SACL privilege on current process
	att.Attributes = SE_PRIVILEGE_ENABLED;
	att.Luid       = LID;

	// There is only one privilege to update
	ns.PrivilegeCount = 1;
	ns.Privileges[0] = att;

	if(!AdjustTokenPrivileges(htoken, FALSE, &ns, 0, NULL, NULL) ) {
		printf("Can't adjust the process privilege.\n");
		return 1;
	}

	return 0;
} /* adjust_privileges() */



VOID assert_null (int val)
{
	if (val != 0) return;
	show_usage();
	ExitProcess(1);	
} /* assert_null() */



int check_switch (char *argv,
		  SE_OBJECT_TYPE ot,
		  SECURITY_INFORMATION *pSI)
{
	int i;
	int res = 0;
	for(i = 1; argv[i] != '\0'; i++) {
		switch (argv[i]) {
		case (_GET_SECURITY_INFOL):
			break;
		case (_SET_SECURITY_INFOL):
			APPLY_SECURITY_SETTINGS = 1;
			break;
		case (_OBJECT_TYPEL) :
			assert_null((int) ot);
			res |= _DO_GET_TYPE;
		case (_GET_DACLL) :
			*pSI |= DACL_SECURITY_INFORMATION;
			break;
		case (_GET_SACLL) :
			*pSI |= SACL_SECURITY_INFORMATION;
			break;
		case (_GET_OWNERL) :
			*pSI |= OWNER_SECURITY_INFORMATION;
			break;
		case (_GET_GROUPL) :
			*pSI |= GROUP_SECURITY_INFORMATION;
			break;
		case (_GET_PROTECTED_DACLL) :
			assert_null((int) *pSI&UNPROTECTED_DACL_SECURITY_INFORMATION);
			*pSI |= PROTECTED_DACL_SECURITY_INFORMATION;
			break;
		case (_GET_PROTECTED_SACLL) :
			assert_null((int) *pSI&UNPROTECTED_SACL_SECURITY_INFORMATION);
			*pSI |= PROTECTED_SACL_SECURITY_INFORMATION;
			break;
		case (_GET_UNPROTECTED_DACLL) :
			assert_null((int) *pSI&PROTECTED_DACL_SECURITY_INFORMATION);
			*pSI |= UNPROTECTED_DACL_SECURITY_INFORMATION;
			break;
		case (_GET_UNPROTECTED_SACLL) :
			assert_null((int) *pSI&PROTECTED_SACL_SECURITY_INFORMATION);
			*pSI |= UNPROTECTED_SACL_SECURITY_INFORMATION;
			break;
		default:
			show_usage();
			ExitProcess(1);		
		}
	}
	return res;
} /* check_switch() */



int get_type (char *argv, 
	      SE_OBJECT_TYPE *pOT)
{
	switch (argv[0]) {
	case (_OBJECT_TYPE_FILEH):
		assert_null((int) *pOT);
		*pOT =  SE_FILE_OBJECT;
		return 0;
	case (_OBJECT_TYPE_REGISTRYH):
		assert_null((int) *pOT);
		*pOT =  SE_REGISTRY_KEY;
		return 0;
	case (_OBJECT_TYPE_SERVICEH) :
		assert_null((int) *pOT);
		*pOT =  SE_SERVICE;
		return 0;
	case (_OBJECT_TYPE_PRINTERH) :
		assert_null((int) *pOT);
		*pOT =  SE_PRINTER;
		return 0;
	case (_OBJECT_TYPE_SHAREH) :
		assert_null((int) *pOT);
		*pOT =  SE_LMSHARE;
		return 0;
	case (_OBJECT_TYPE_KERNELH) :
		assert_null((int) *pOT);
		// *pOT =  SE_KERNEL; // Not defined in headers !
		*pOT =  (SE_OBJECT_TYPE) -1;
		return 0;
	case (_OBJECT_TYPE_WINDOWH) :
		show_usage();
		ExitProcess(1);
	case (_OBJECT_TYPE_DSOBJECTH) :
		assert_null((int) *pOT);
		*pOT =  SE_DS_OBJECT;
		return 0;
	case (_OBJECT_TYPE_DSOBJALLH) :
		assert_null((int) *pOT);
		*pOT =  SE_DS_OBJECT_ALL;
		return 0;
	case (_OBJECT_TYPE_PROVIDERH) :
		assert_null((int) *pOT);
		*pOT =  SE_PROVIDER_DEFINED_OBJECT;
		return 0;
	case (_OBJECT_TYPE_WMIGUIDH) :
		assert_null((int) *pOT);
		*pOT =  SE_WMIGUID_OBJECT;
		return 0;
	case (_OBJECT_TYPE_WOW64_REGH) :
		assert_null((int) *pOT);
		*pOT =  SE_REGISTRY_WOW64_32KEY;
		return 0;
	default:
		show_usage();
		ExitProcess(1);
	}
	return 0;
} /* get_type() */



VOID get_object (char *argv, char **szObject, char **szSecDesc)
{
	if (!*szObject) *szObject = argv;
	else *szSecDesc = argv;
} /* get_object() */



int apply_sd(char *szObject, 
	     char *szSecDesc,
	     SECURITY_INFORMATION si,
	     SE_OBJECT_TYPE ot)
{
	if (!szSecDesc) return 1;
	int re;

	PSECURITY_DESCRIPTOR pSD = NULL;
	PACL pDACL 	= NULL;
	PACL pSACL 	= NULL;
	PSID pOwner 	= NULL;
	PSID pGroup 	= NULL;
	LPBOOL lpbPresent = (LPBOOL) malloc(sizeof(BOOL));
	LPBOOL lpbDefaulted = (LPBOOL) malloc(sizeof(BOOL));

	ConvertStringSecurityDescriptorToSecurityDescriptor(szSecDesc,
							    SDDL_REVISION_1,
							    &pSD,
							    NULL);
	// Get pointers as defined by flags
	if (si & DACL_SECURITY_INFORMATION)
		GetSecurityDescriptorDacl(pSD, lpbPresent, &pDACL, lpbDefaulted);
	if (si & SACL_SECURITY_INFORMATION)
		GetSecurityDescriptorSacl(pSD, lpbPresent, &pSACL, lpbDefaulted);
	if (si & OWNER_SECURITY_INFORMATION)
		GetSecurityDescriptorOwner(pSD, &pOwner, lpbDefaulted);
	if (si & GROUP_SECURITY_INFORMATION)
		GetSecurityDescriptorGroup(pSD, &pGroup, lpbDefaulted);

	re = SetNamedSecurityInfo(szObject, ot, si,
				  pOwner, pGroup, pDACL, pSACL);
	free(lpbPresent);
	free(lpbDefaulted);
	free(pSD);

	if (re==ERROR_SUCCESS) return 0;

	re = GetLastError();
	if (re==0) {
		re = 1;
		fprintf(stderr, 
			"SetNamedSecurityInfo() Failed!\n%d "	\
			"Non existant object!", re);			
	} else {
		fprintf(stderr, 
			"SetNamedSecurityInfo() Failed!\n%d %s",
			re, get_error_string(re));
	}
	return re;
} /* apply_sd */



int show_sd(char *szObject, 
	    char *szSecDesc,
	    SECURITY_INFORMATION si,
	    SE_OBJECT_TYPE ot)
{
	int re;
	PSECURITY_DESCRIPTOR pSD = NULL;
	PACL pDACL 	= NULL;
	PACL pSACL 	= NULL;
	PSID pOwner 	= NULL;
	PSID pGroup 	= NULL;

	// Get a copy of security descriptor
	re = GetNamedSecurityInfo(
				  szObject, ot, si,
				  &pOwner, &pGroup, &pDACL, &pSACL,
				  &pSD);
	// Try again to get DACL only, even on ERROR_PRIVILEGE_NOT_HELD
	if (re==ERROR_PRIVILEGE_NOT_HELD)
		re = GetNamedSecurityInfo(
					  szObject, ot,
					  DACL_SECURITY_INFORMATION,
					  &pOwner, &pGroup, &pDACL, &pSACL,
					  &pSD);
	if (re!=ERROR_SUCCESS) {
		free(pSD);
		re = GetLastError();
		fprintf(stderr,
			"GetNamedSecurityInfo() Failed!\n%d %s",
			re,
			get_error_string(re));
		return re;
	}

	// Get security desciptor string and write to standard out
	re = ConvertSecurityDescriptorToStringSecurityDescriptor(pSD,
								 SDDL_REVISION_1,
								 si,
								 &szSecDesc,
								 NULL);
	free(pSD);
	if (!re) {
		re = GetLastError();
		fprintf(stderr,
			"ConvertSecurityDescriptorToStringSecurityDescriptor()"	\
			" Failed!\n%d %s\n", re, get_error_string(re));
		return re;
	} else {
		printf("%s\n", szSecDesc);
	}
	return re;
}



int main (int argc, char **argv) 
{
	// Check input
	if (argc < 2) {
		show_usage();
		ExitProcess(1);
	}

	LPTSTR szObject 	= NULL;
	LPTSTR szSecDesc 	= NULL;
	SECURITY_INFORMATION 	si = (SECURITY_INFORMATION) 0;
	SE_OBJECT_TYPE 		ot = SE_FILE_OBJECT;
	
	int i;
	int res = 0;
	for (i=1;i<argc;i++) {
		if (argv[i][0] == '-') res = check_switch(argv[i], ot, &si);
		else if (res&_DO_GET_TYPE) res = get_type(argv[i], &ot);
		else get_object(argv[i], &szObject, &szSecDesc);
	}

	if (!szObject) {
		if (szSecDesc) free(szSecDesc);
		show_usage();
		ExitProcess(1);
	}

	// Default object type is file, 
	// for compatibility with previous versions
	if (ot==0) ot = SE_FILE_OBJECT;

	// Get privilege to read ACL of object
        res = adjust_privileges(SE_SECURITY_NAME);

	if (APPLY_SECURITY_SETTINGS)
		res = apply_sd(szObject, szSecDesc, si, ot);
	else 
		res = show_sd(szObject, szSecDesc, si, ot);

	free(szObject);
	free(szSecDesc);
	fflush(stdout);
	fflush(stderr);

	ExitProcess(res);
} /* main() */
