REM
REM **  PoqNT installation file  **
REM
net user poq poq /add /active:yes /comment:"Poq NT service user"
REM move poq.conf %WINDIR%\System32
move /y poq.exe %WINDIR%\System32
%WINDIR%\System32\poq.exe /install
rem net start PoqNT
