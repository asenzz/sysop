REM
REM **  PoqNT uninstallation  **
REM
net stop PoqNT
%WINDIR%\System32\poq.exe /uninstall
erase /f /q %WINDIR%\System32\poq.exe
net user poq /delete
