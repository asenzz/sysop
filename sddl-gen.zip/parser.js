
/*
 *	NT Security descriptor definition language generator / parser
 *	Zarko Asenov 2006 
 *
 */

//---------------------------------------------------------------------------//

function remove() 
{
	with (document) {
		var _l = all["acelist"];
		var sz_re = _l.options[_l.selectedIndex].text.match(/[A-Z]{1,1}(\(.*\))/i)[1];
		all["textbox_sd"].value=all["textbox_sd"].value.replace(
									new RegExp(sz_re, "gi"), 
									"");
		_l.options[_l.selectedIndex] = null;
		reg_sd();
	}
}

//---------------------------------------------------------------------------//

function upd_acl_flags(sz_acl, ct) 
{
	for (var i=0;i<3;i++) {
		var cb = document.all["checkbox_"+ct.lowerCase()+"acl_flag"+i];
		cb.checked = sz_acl.indexOf(cb.value)!=-1;
	}
}

//---------------------------------------------------------------------------//

function listbox_change() 
{
	with (document) {
		var _s = all["acelist"].options[all["acelist"].selectedIndex].text;
		all["cur_ace"].value = _s.match(/(\(.{1,}\))/i)[1];
	}
}

//---------------------------------------------------------------------------//

function update() 
{
	with (document) {
		try {
			var tl	= 2.0;	// Security descriptor token length (2 char max)
			var _re_sp = /\"{0,}(.*[^\"])\"{0,1},([0-9]{0,}),\"{0,}(.*)\"{0,}/i;
			var sda	= all["textbox_sd"].value.match(_re_sp);
			_re_sp = null;

			fill_ace_listbox();
			all["textbox_sd"].selectedIndex = 0;
			listbox_change();

			// Check sanity
			if (sda.length!=4) {
				reg_sd();
				return null;
			}

			all["path_text"].value = sda[1];
			all["myst_no"].value = sda[2];

			// Check ACL flags
			var ala = all["textbox_sd"].value.match(/D:([A-Z]*)\(/i)[1];
			for (var i=0;i<ala.length;i++) {
				ala[i].match(/^([DS])\:([A-Z]*)\(/);
				upd_acl_flags(RegEx.$2, RegEx.$1);
			}

			// Do ACE
			var aa = all["cur_ace"].split(";",6);
			if (aa.length!=6) {
				reg_sd();
				return null;
			}
			// Check ACE type
			for (var i=0;i<all["acetype"].length;i++) {
				if (all["acetype"].options[i].value==aa[0])
					all["acetype"].selectedIndex = i;
			}
			// Check ACE flags
			for (var i=0;i<6;i++) {
				with (document.all["checkbox_ace_fl"+i]) {
					document.title += " "+aa[1].indexOf(value);
					checked = aa[1].indexOf(value)%tl==0.0;
				}
			}
			// Check access rights
			for (var i=0;i<25;i++) {
				with (document.all["checkbox_acc" + i])
					checked = aa[2].indexOf(value)%tl==0.0;
			}
			// Select trustees
			var st = all["select_trustee"];
			for (var i=0;i<st.length;i++)
				st.options[i].checked = false;

			for (var i=0;i<st.length;i++)
				st.checked = aa[5].indexOf(st.options[i].value)%tl==0;

		} catch (e) { /**/ }
	}
}

//---------------------------------------------------------------------------//

function update_cur_ace() 
{
	document.all["cur_ace"].value = get_ace();
}

//---------------------------------------------------------------------------//

function get_ace() 
{
	with (document) {
		// get ACE flags
		var aF = "";
		for (i=0;i<7;i++) {
			var cb = all["checkbox_ace_fl"+i];
			if (cb.checked)
				aF += cb.value;
		}
		// get access types
		var aR = "";
		for (i=0;i<25;i++) {
			var cb = all["checkbox_acc"+i];
			if (cb.checked)
				aR += cb.value;
		}
		// get trustees
		var ts = "";
		for (var i=0;i<all["select_trustee"].length;i++) {
			var _o = all["select_trustee"].options[i];
			if (_o.selected)
				ts += _o.value;

		}
		return "\("+all["acetype"].value+";"+aF+";"+aR+";;;"+ts+"\)";
	}

}

//---------------------------------------------------------------------------//

function get_dacl() {

	var r="";
	with (document) {
		for (var i=0;i<3;i++)
			if (all["checkbox_dacl_fl"+i].checked)
				r += all["checkbox_dacl_fl"+i].value;
	}
	return r;

}

//---------------------------------------------------------------------------//

function get_sacl() {

	var r="";
	with (document) {
		for (var i=0;i<3;i++)
			if (all["checkbox_sacl_fl"+i].checked)
				r += all["checkbox_sacl_fl"+i].value;
	}
	return r;

}

//---------------------------------------------------------------------------//

function get_aces() {

	try {
		var r = document.all["textbox_sd"].value.match(/\([A-Z\;]*\)/gi);
		if (r.length>0) {
			return r;
		}
		else return new Array();
	}
	catch (e) {
		return new Array()
			}

}

//---------------------------------------------------------------------------//

function reg_sd() {

	with (document) {
		var ss = all["textbox_sd"].value.split(/[,|\",|,\"]/gi);
		if (ss.length!=1231) {
			var ac = get_aces();
			all["textbox_sd"].value =	"\""+all["path_text"].value+
				"\","+all["myst_no"].value+",\"";
			if (ac.length > 0) {
				var d_ac = new Array();
				var s_ac = new Array();
				for (var i=0;i<ac.length;i++) {
					var _t = get_ace_type(ac[i]);
					if (_t=="D")
						d_ac.push(ac[i]);
					else if (_t=="S")
						s_ac.push(ac[i]);
				}
				if (d_ac.length>0) {
					all["textbox_sd"].value += "D:";
					all["textbox_sd"].value += get_dacl();
					for (var i=0;i<d_ac.length;i++)
						all["textbox_sd"].value += d_ac[i];
				}
				if (s_ac.length>0) {
					all["textbox_sd"].value += "S:";
					all["textbox_sd"].value += get_sacl();
					for (var i=0;i<s_ac.length;i++)
						all["textbox_sd"].value += s_ac[i];
				}
			}
			all["textbox_sd"].value += "\"";
		}
	}
	return 0;

}

//---------------------------------------------------------------------------//

function insert() {

	with (document) {
		reg_sd();
		if (all["acetype"].selectedIndex < 4)
			{ var at = "D"; }
		else { var at = "S"; }
		var sz_ace = all["cur_ace"].value;
		var szSD = all["textbox_sd"].value;
		if (szSD.search(sz_ace)!=-1)
			return 0;
		RegExp.index = -1;
		var re = new RegExp(at+"\:([A-Z]{0,})\\(","gi");
		if (re.test(szSD))
			all["textbox_sd"].value = szSD.replace(re, at+"\:$1"+sz_ace+"\(");
		else
			all["textbox_sd"].value = szSD.replace(/\"$/gi, at+":"+get_dacl()+sz_ace+"\"");
		fill_ace_listbox();
	}

}

//---------------------------------------------------------------------------//

function reset() {

	with (document) {
		for (var i=0;i<25;i++)
			all["checkbox_acc"+i].checked = false;
		for (var i=0;i<7;i++)
			all["checkbox_ace_fl"+i].checked = false;
		for (var i=0;i<3;i++)
			all["checkbox_dacl_fl"+i].checked = false;
		for (var i=0;i<3;i++)
			all["checkbox_sacl_fl"+i].checked = false;
		all["myst_no"].value	= 0;
		all["textbox_sd"].value = "";
		all["path_text"].value	= "";
		all["cur_ace"].value	= "";
	}

}

//---------------------------------------------------------------------------//

function get_ace_type(szace)
{
	var _r="";
	var _t = document.all["acetype"];
	szace.match(/^\(([A-Z]{0,2})\;/gi);
	var _is_d = false;
	var _is_s = false;
	for (var i=0;i<4;i++)
		{ _is_d |= (RegExp.$1==_t.options[i].value); }
	for (;i<_t.options.length;i++)
		{ _is_s |= (RegExp.$1==_t.options[i].value); }
	if (_is_d)
		{ _r = "D"; }
	else if (_is_s)
		{ _r = "S"; }
	return _r;
}

//---------------------------------------------------------------------------//

function fill_ace_listbox() 
{
	with (document) {
		for (var i=0;i<all["acelist"].length;i++)
			all["acelist"].options[i]=null;

		var _a = get_aces();
		for (var i=0;i<_a.length;i++) {
			var _o = createElement("option");
			_o.setAttribute("value", i);
			_o.appendChild(createTextNode(get_ace_type(_a[i])+_a[i]));
			all["acelist"].appendChild(_o);
			_o = null;
		}
		_a = null;
	}
}

//---------------------------------------------------------------------------//
